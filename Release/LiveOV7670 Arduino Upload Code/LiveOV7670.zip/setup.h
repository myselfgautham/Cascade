#ifndef LIVEOV7670_SETUP_H
#define LIVEOV7670_SETUP_H

void initializeScreenAndCamera();
void processFrame();

#endif